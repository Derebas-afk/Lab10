public abstract class Animal {
    public abstract void run(double distance);
    public abstract void swim(double meters);
    public abstract void jump(double height);
}